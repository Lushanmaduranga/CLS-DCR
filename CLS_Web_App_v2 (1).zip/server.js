'use strict';
/* =====================================================================
   CLS Reporting System v2 - web server (no external packages, Node 18+)
   - Fixed access list (roster.json): names, roles, reporting lines
   - Employee-code login with hashed passwords
   - One shared data store (data/db.json) with daily backups
   - Role rules enforced HERE (MPO own data / FM own team / BM everything)
   ===================================================================== */
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto'), zlib = require('zlib');

const PORT = parseInt(process.env.PORT, 10) || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');
const DB_FILE = path.join(DATA_DIR, 'db.json'), BK_DIR = path.join(DATA_DIR, 'backups'), AUDIT = path.join(DATA_DIR, 'audit.log');
fs.mkdirSync(BK_DIR, { recursive: true });

/* Optional: let your SharePoint / Teams page show this site inside a frame.
   Example: FRAME_ANCESTORS=https://cicholdings.sharepoint.com https://teams.microsoft.com */
const FRAME = /^[A-Za-z0-9:\/.\-*\s]+$/.test(process.env.FRAME_ANCESTORS || '') ? String(process.env.FRAME_ANCESTORS).trim() : '';

/* ---------------- secret for sign-in tokens ---------------- */
let SECRET = process.env.CIC_SECRET;
if (!SECRET) {
  const f = path.join(DATA_DIR, 'secret.key');
  try { SECRET = fs.readFileSync(f, 'utf8').trim(); }
  catch (e) { SECRET = crypto.randomBytes(32).toString('hex'); fs.writeFileSync(f, SECRET, { mode: 0o600 }); }
}

/* ---------------- helpers ---------------- */
const norm = s => String(s == null ? '' : s).toLowerCase().replace(/\s+/g, ' ').trim();
const nowIso = () => new Date().toISOString();
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function tempPw() { const b = crypto.randomBytes(10); let s = ''; for (let i = 0; i < 10; i++) s += ALPHA[b[i] % 32]; return s.slice(0, 5) + '-' + s.slice(5); }
function hashPw(pw, salt) { return crypto.scryptSync(String(pw), Buffer.from(salt, 'hex'), 32).toString('hex'); }
function setPw(u, pw, must) { u.salt = crypto.randomBytes(16).toString('hex'); u.hash = hashPw(pw, u.salt); u.mustChange = !!must; u.tokenVer = (u.tokenVer || 0) + 1; }
function checkPw(u, pw) {
  const salt = u && u.salt ? u.salt : '00'.repeat(16);
  const a = Buffer.from(hashPw(pw, salt), 'hex');          /* same work for unknown users */
  if (!u || !u.hash) return false;
  return crypto.timingSafeEqual(a, Buffer.from(u.hash, 'hex'));
}
function sign(p) { const body = Buffer.from(JSON.stringify(p)).toString('base64url'); return body + '.' + crypto.createHmac('sha256', SECRET).update(body).digest('base64url'); }
function verify(t) {
  if (typeof t !== 'string') return null; const i = t.indexOf('.'); if (i < 1) return null;
  const body = t.slice(0, i), sig = t.slice(i + 1), exp = crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
  const A = Buffer.from(sig), B = Buffer.from(exp); if (A.length !== B.length || !crypto.timingSafeEqual(A, B)) return null;
  try { const p = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')); return p.exp > Date.now() ? p : null; } catch (e) { return null; }
}

/* ---------------- database + fixed roster ---------------- */
const ROSTER = JSON.parse(fs.readFileSync(path.join(__dirname, 'roster.json'), 'utf8'));
if (!Array.isArray(ROSTER) || !ROSTER.length || !ROSTER.some(r => r.role === 'bm' && !r.vacant)) { console.error('roster.json is not valid (it needs at least one BM).'); process.exit(1); }
let db = null;
if (fs.existsSync(DB_FILE)) {
  try { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); }
  catch (e) { console.error('db.json cannot be read (' + e.message + '). Server stopped so nothing is overwritten. Restore a file from data/backups.'); process.exit(1); }
}
const firstRun = !db;
if (!db) db = { v: 2, usersRev: 1, users: [], keys: {} };
/* The roster file is the single source of truth for names, roles and reporting lines. Only passwords live in the database. */
function syncRoster() {
  let changed = false; const byCode = {}; db.users.forEach(u => { byCode[String(u.code).toUpperCase()] = u; });
  const next = ROSTER.map(r => {
    const old = byCode[r.code.toUpperCase()];
    const u = old || { code: r.code, salt: null, hash: null, mustChange: true, tokenVer: 0, created: nowIso(), lastLogin: '' };
    const want = { code: r.code, name: r.name, role: r.role, reportsTo: r.reportsTo || '', pid: r.pid, vacant: !!r.vacant, active: !r.vacant, left: false };
    for (const k of Object.keys(want)) if (u[k] !== want[k]) { u[k] = want[k]; changed = true; }
    if (!old) changed = true;
    return u;
  });
  if (next.length !== db.users.length) changed = true;
  db.users = next;
  if (changed) db.usersRev = (db.usersRev || 0) + 1;
  return changed;
}
const rosterChanged = syncRoster();
let dirty = firstRun || rosterChanged, timer = null;
if (firstRun) {
  const bm = db.users.find(u => u.role === 'bm' && !u.vacant);
  const pw = process.env.CIC_ADMIN_PASSWORD || tempPw();
  setPw(bm, pw, !process.env.CIC_ADMIN_PASSWORD);
  fs.writeFileSync(path.join(DATA_DIR, 'FIRST-RUN-ADMIN-PASSWORD.txt'), 'Business Manager sign-in\nEmployee code: ' + bm.code + '\nPassword: ' + pw + '\n\nDelete this file once you have signed in and chosen your own password.\n', { mode: 0o600 });
  console.log('\n=== FIRST RUN ===\nBusiness Manager code: ' + bm.code + '\nPassword: ' + pw + '\n(also saved in data/FIRST-RUN-ADMIN-PASSWORD.txt - delete it after sign-in)\n');
}
function touch() { dirty = true; if (!timer) timer = setTimeout(flush, 250); }
function flush() {
  if (timer) { clearTimeout(timer); timer = null; }
  if (!dirty) return; dirty = false;
  const tmp = DB_FILE + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(db)); fs.renameSync(tmp, DB_FILE);
  try {
    const day = nowIso().slice(0, 10), bk = path.join(BK_DIR, 'db-' + day + '.json');
    if (!fs.existsSync(bk)) {
      fs.copyFileSync(DB_FILE, bk);
      const all = fs.readdirSync(BK_DIR).filter(f => /^db-\d{4}-\d\d-\d\d\.json$/.test(f)).sort();
      all.slice(0, Math.max(0, all.length - 30)).forEach(f => { try { fs.unlinkSync(path.join(BK_DIR, f)); } catch (e) {} });
    }
  } catch (e) { console.error('backup failed', e.message); }
}
flush();
['SIGTERM', 'SIGINT'].forEach(s => process.on(s, () => { try { flush(); } catch (e) {} process.exit(0); }));
process.on('exit', () => { try { flush(); } catch (e) {} });
function audit(o) { try { fs.appendFileSync(AUDIT, JSON.stringify(Object.assign({ t: nowIso() }, o)) + '\n'); } catch (e) {} }

const findUser = c => { c = String(c || '').trim().toUpperCase(); return db.users.find(u => u.code.toUpperCase() === c) || null; };
const pub = (u, self) => { const o = { code: u.code, name: u.name, role: u.role, reportsTo: u.reportsTo, pid: u.pid, active: u.active !== false, vacant: !!u.vacant }; if (self) o.mustChange = !!u.mustChange; return o; };
const roster = () => db.users.map(u => pub(u));

/* ---------------- data keys and who may see / change what ---------------- */
const KEYS = {
  'cic-local-visits-v1': { t: 'arr', own: 'mpo' },
  'cic-doctor-visits-v1': { t: 'arr', own: 'mpo' },
  'cic-sponsorship-v1': { t: 'arr', own: 'mpo' },
  'cic-pharmacy-activities-v1': { t: 'arr', own: 'mpo' },
  'cic-rx-v1': { t: 'arr', own: 'mpo' },
  'cic-fm-queue-v1': { t: 'arr', own: 'queue' },
  'cic-master-pharm-v1': { t: 'arr', own: 'shared' },
  'cic-master-doc-v1': { t: 'arr', own: 'shared' },
  'cic-ph-ops': { t: 'arr', own: 'shared', append: true },
  'cic-doc-ops': { t: 'arr', own: 'shared', append: true },
  'cic-tour-plan-v1': { t: 'obj' },
  'cic-expenses-v1': { t: 'obj' },
  'cic-ytd-targets-v1': { t: 'blob' },
  'cic-sql-sales-v1': { t: 'blob' },
  'cic-sql-manual-v1': { t: 'blob' },
  'cic-dist-stock-v1': { t: 'blob' }
};
const D3 = new Set(['plans', 'status', 'claims']), D2 = new Set(['maps', 'profiles']);
function K(key) {
  const d = KEYS[key]; let k = db.keys[key];
  if (!k) { k = db.keys[key] = d.t === 'arr' ? { rev: 0, items: {}, order: [] } : d.t === 'obj' ? { rev: 0, o: {} } : { rev: 0, s: null }; }
  return k;
}
function scopeFor(user) {
  if (user.role === 'bm') return { all: true };
  let list = [user];
  if (user.role === 'fm') list = list.concat(db.users.filter(x => x.role === 'mpo' && x.reportsTo === user.code));
  return { all: false, codes: new Set(list.map(u => u.code.toUpperCase())), names: new Set(list.map(u => norm(u.name))), pids: new Set(list.map(u => u.pid)) };
}
function labelIn(sc, m) {
  if (sc.all) return true; if (m == null || m === '') return false; m = String(m);
  const i = m.indexOf('\u00b7'), code = (i >= 0 ? m.slice(0, i) : '').trim().toUpperCase();
  if (code && sc.codes.has(code)) return true;
  return sc.names.has(norm(i >= 0 ? m.slice(i + 1) : m));
}
function recCan(def, user, sc, rec, forWrite) {
  if (!rec || typeof rec !== 'object') return false;
  if (def.own === 'mpo') return labelIn(sc, rec.mpo);
  if (def.own === 'queue') return sc.all || (rec.byCode ? sc.codes.has(String(rec.byCode).toUpperCase()) : user.role !== 'mpo');
  if (def.own === 'shared') return forWrite ? (user.role === 'fm' || user.role === 'bm') : true;
  return false;
}
function pathInfo(p) {
  if (!Array.isArray(p) || !p.length || p.length > 3) return null;
  for (const s of p) if (typeof s !== 'string' || s === '__proto__' || s === 'constructor' || s === 'prototype' || s.length > 120) return null;
  const top = p[0];
  if (D3.has(top)) return p.length === 3 ? { pid: p[2] } : null;
  if (D2.has(top)) return p.length === 2 ? { pid: p[1] } : null;
  return p.length === 1 ? { pid: null } : null;
}
function pathCan(user, sc, info) { return info.pid ? (sc.all || sc.pids.has(info.pid)) : (user.role === 'fm' || user.role === 'bm'); }

function readKey(key, user, sc) {
  const def = KEYS[key], k = K(key);
  if (def.t === 'arr') { const out = []; for (const id of k.order) { const r = k.items[id]; if (r !== undefined && recCan(def, user, sc, r, false)) out.push(r); } return out; }
  if (def.t === 'blob') return k.s;
  const out = {};
  for (const top of Object.keys(k.o)) {
    const v = k.o[top];
    if (D3.has(top)) { out[top] = {}; for (const m of Object.keys(v)) { const mm = {}; for (const pid of Object.keys(v[m])) if (sc.all || sc.pids.has(pid)) mm[pid] = v[m][pid]; out[top][m] = mm; } }
    else if (D2.has(top)) { out[top] = {}; for (const pid of Object.keys(v)) if (sc.all || sc.pids.has(pid)) out[top][pid] = v[pid]; }
    else out[top] = v;
  }
  return out;
}
function applyDelta(key, user, sc, d) {
  const def = KEYS[key], k = K(key); let up = 0, del = 0, rej = 0;
  if (!d || typeof d !== 'object') return { up, del, rej, changed: false };
  if (def.t === 'arr') {
    const delIds = new Set();
    for (const x of Array.isArray(d.del) ? d.del : []) {
      const id = String(x); const ex = k.items[id]; if (ex === undefined) continue;
      if (!recCan(def, user, sc, ex, true)) { rej++; continue; } delete k.items[id]; delIds.add(id); del++;
    }
    if (delIds.size) k.order = k.order.filter(i => !delIds.has(i));
    const fresh = [];
    for (const it of Array.isArray(d.up) ? d.up : []) {
      if (!it || typeof it.id !== 'string' || !it.id || it.id.length > 200 || !it.rec || typeof it.rec !== 'object' || Array.isArray(it.rec)) { rej++; continue; }
      const ex = k.items[it.id];
      if (ex !== undefined && !recCan(def, user, sc, ex, true)) { rej++; continue; }
      if (!recCan(def, user, sc, it.rec, true)) { rej++; continue; }
      if (ex === undefined) { fresh.push(it.id); k.items[it.id] = it.rec; up++; }
      else if (JSON.stringify(ex) !== JSON.stringify(it.rec)) { k.items[it.id] = it.rec; up++; }
    }
    if (fresh.length) k.order = def.append ? k.order.concat(fresh) : fresh.concat(k.order);
  } else if (def.t === 'blob') {
    if (typeof d.s === 'string') {
      if (user.role !== 'bm' || d.s.length > 12000000) rej++; else if (k.s !== d.s) { k.s = d.s; up++; }
    }
  } else {
    for (const it of Array.isArray(d.up) ? d.up : []) {
      const info = it && pathInfo(it.p); if (!info || !pathCan(user, sc, info) || it.v === undefined) { rej++; continue; }
      let o = k.o; for (let i = 0; i < it.p.length - 1; i++) { if (!o[it.p[i]] || typeof o[it.p[i]] !== 'object') o[it.p[i]] = {}; o = o[it.p[i]]; }
      const last = it.p[it.p.length - 1]; if (JSON.stringify(o[last]) !== JSON.stringify(it.v)) { o[last] = it.v; up++; }
    }
    for (const p of Array.isArray(d.del) ? d.del : []) {
      const info = pathInfo(p); if (!info || !pathCan(user, sc, info)) { rej++; continue; }
      let o = k.o; for (let i = 0; i < p.length - 1 && o; i++) o = o[p[i]];
      if (o && typeof o === 'object' && Object.prototype.hasOwnProperty.call(o, p[p.length - 1])) { delete o[p[p.length - 1]]; del++; }
    }
  }
  const changed = up > 0 || del > 0; if (changed) { k.rev++; touch(); }
  return { up, del, rej, changed };
}

/* ---------------- sessions, sign-in limits ---------------- */
const fails = new Map();
const lockLeft = key => { const f = fails.get(key); return f && f.until > Date.now() ? Math.ceil((f.until - Date.now()) / 1000) : 0; };
const addFail = key => { const f = fails.get(key) || { n: 0, until: 0 }; f.n++; if (f.n % 5 === 0) f.until = Date.now() + 60000 * Math.min(15, Math.pow(2, f.n / 5 - 1)); fails.set(key, f); };
setInterval(() => { const t = Date.now(); for (const [k, f] of fails) if (f.until < t - 3600000) fails.delete(k); }, 600000).unref();
function issue(u, remember) { return sign({ c: u.code, v: u.tokenVer || 0, exp: Date.now() + (remember ? 7 * 24 : 12) * 3600 * 1000 }); }
function authUser(req) {
  const h = req.headers.authorization || ''; const p = verify(h.startsWith('Bearer ') ? h.slice(7) : '');
  if (!p) return null; const u = findUser(p.c);
  if (!u || u.active === false || u.vacant || (u.tokenVer || 0) !== p.v) return null; return u;
}
const clientIp = req => String((req.headers['x-forwarded-for'] || req.socket.remoteAddress || '')).split(',')[0].trim();

/* ---------------- http plumbing ---------------- */
function baseHeaders(req, type) {
  const h = { 'Content-Type': type, 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin' };
  if (FRAME) h['Content-Security-Policy'] = "frame-ancestors 'self' " + FRAME; else h['X-Frame-Options'] = 'SAMEORIGIN';
  if (String(req.headers['x-forwarded-proto'] || '').split(',')[0] === 'https') h['Strict-Transport-Security'] = 'max-age=15552000';
  return h;
}
function send(req, res, status, body, type, extra) {
  const buf = Buffer.isBuffer(body) ? body : Buffer.from(typeof body === 'string' ? body : JSON.stringify(body));
  const h = Object.assign(baseHeaders(req, type || 'application/json; charset=utf-8'), extra || {});
  if (buf.length > 1024 && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) { h['Content-Encoding'] = 'gzip'; res.writeHead(status, h); res.end(zlib.gzipSync(buf)); }
  else { res.writeHead(status, h); res.end(buf); }
}
const err = (req, res, status, msg, extra) => send(req, res, status, Object.assign({ error: msg }, extra || {}), null, { 'Cache-Control': 'no-store' });
const ok = (req, res, o) => send(req, res, 200, o, null, { 'Cache-Control': 'no-store' });
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let n = 0; const ch = [];
    req.on('data', c => { n += c.length; if (n > limit) { reject(new Error('too large')); req.destroy(); } else ch.push(c); });
    req.on('end', () => { try { resolve(n ? JSON.parse(Buffer.concat(ch).toString('utf8')) : {}); } catch (e) { reject(new Error('bad json')); } });
    req.on('error', reject);
  });
}
function snapshotFor(user, clientRevs) {
  const sc = scopeFor(user), out = {};
  for (const key of Object.keys(KEYS)) { const k = K(key); if (k.rev && k.rev !== ((clientRevs && clientRevs[key]) | 0)) out[key] = { rev: k.rev, v: readKey(key, user, sc) }; }
  return out;
}
const strongEnough = (pw, u) => typeof pw === 'string' && pw.length >= 8 && pw.length <= 100 && norm(pw) !== norm(u.code) && !/^cic@?\d+$/i.test(pw);

/* ---------------- routes ---------------- */
let HTML_CACHE = null;
async function route(req, res) {
  const url = new URL(req.url, 'http://x'), p = url.pathname, m = req.method;
  if (m === 'GET' && (p === '/' || p === '/index.html')) {
    const f = path.join(PUBLIC_DIR, 'index.html');
    if (!HTML_CACHE || HTML_CACHE.t !== fs.statSync(f).mtimeMs) HTML_CACHE = { t: fs.statSync(f).mtimeMs, b: fs.readFileSync(f), z: null };
    const h = baseHeaders(req, 'text/html; charset=utf-8'); h['Cache-Control'] = 'no-cache';
    if (/\bgzip\b/.test(req.headers['accept-encoding'] || '')) { if (!HTML_CACHE.z) HTML_CACHE.z = zlib.gzipSync(HTML_CACHE.b, { level: 9 }); h['Content-Encoding'] = 'gzip'; res.writeHead(200, h); return res.end(HTML_CACHE.z); }
    res.writeHead(200, h); return res.end(HTML_CACHE.b);
  }
  if (m === 'GET' && p === '/healthz') return send(req, res, 200, 'ok', 'text/plain');
  if (!p.startsWith('/api/')) return send(req, res, 404, 'Not found', 'text/plain');

  let body = {};
  if (m === 'POST') { try { body = await readBody(req, 40 * 1024 * 1024); } catch (e) { return err(req, res, 400, 'Bad request'); } }

  if (m === 'POST' && p === '/api/login') {
    const code = String(body.code || '').trim(), ip = clientIp(req), kU = 'u|' + code.toUpperCase(), kI = 'i|' + ip;
    const wait = Math.max(lockLeft(kU), lockLeft(kI));
    if (wait) return err(req, res, 429, 'Too many attempts. Please wait ' + wait + ' seconds.', { wait });
    let u = findUser(code);
    if (!u && /^\d+$/.test(code)) { const c = db.users.filter(x => (/(\d+)$/.exec(x.code) || [])[1] === code); if (c.length === 1) u = c[0]; }
    if (u && u.vacant) return err(req, res, 403, 'This position is vacant, so nobody can sign in with it.');
    const pwRaw = String(body.password || ''); let good = checkPw(u, pwRaw);
    if (!good && pwRaw !== pwRaw.trim()) good = checkPw(u, pwRaw.trim());      /* phone keyboards often add a space */
    if (!u || !good) { addFail(kU); addFail(kI); audit({ ev: 'login-fail', code, ip }); return err(req, res, 401, 'Incorrect employee code or password.'); }
    fails.delete(kU); u.lastLogin = nowIso(); touch(); audit({ ev: 'login', code: u.code, ip });
    return ok(req, res, { token: issue(u, !!body.remember), user: pub(u, true), users: roster(), usersRev: db.usersRev, snapshot: snapshotFor(u, {}) });
  }

  const user = authUser(req);
  if (!user) return err(req, res, 401, 'Please sign in again.');

  if (m === 'POST' && p === '/api/sync') {
    const sc = scopeFor(user), acks = {}, deltas = body.deltas && typeof body.deltas === 'object' ? body.deltas : {}, revs = body.revs && typeof body.revs === 'object' ? body.revs : {};
    for (const key of Object.keys(deltas)) {
      if (!KEYS[key]) continue; const k = K(key), prev = k.rev, r = applyDelta(key, user, sc, deltas[key]);
      acks[key] = { rev: k.rev, prev, rej: r.rej };
      if (r.up || r.del || r.rej) audit({ ev: 'sync', u: user.code, k: key, up: r.up, del: r.del, rej: r.rej });
    }
    const updates = snapshotFor(user, revs);
    for (const key of Object.keys(acks)) { const a = acks[key]; if (updates[key] && a.rej === 0 && a.prev === ((revs[key]) | 0)) delete updates[key]; }
    const o = { acks, updates, usersRev: db.usersRev, me: pub(user, true) };
    if (body.usersRev !== db.usersRev) o.users = roster();
    return ok(req, res, o);
  }
  if (m === 'POST' && p === '/api/logout') return ok(req, res, { ok: true });
  if (m === 'POST' && p === '/api/password') {
    if (!checkPw(user, String(body.old || '')) && !(user.mustChange && body.old === '')) return err(req, res, 400, 'Your current password is not correct.');
    if (!strongEnough(body.new, user)) return err(req, res, 400, 'Please choose a password of at least 8 characters that is not your employee code.');
    setPw(user, body.new, false); touch(); audit({ ev: 'password', u: user.code });
    return ok(req, res, { token: issue(user, !!body.remember), user: pub(user, true) });
  }

  /* ---- Business Manager: view the fixed list, reset passwords, backup ---- */
  if (p.startsWith('/api/admin/')) {
    if (user.role !== 'bm') return err(req, res, 403, 'Only the Business Manager can do this.');
    const full = u => Object.assign(pub(u), { lastLogin: u.lastLogin || '', mustChange: !!u.mustChange, hasPassword: !!u.hash });
    if (m === 'GET' && p === '/api/admin/users') return ok(req, res, { users: db.users.map(full) });
    if (m === 'GET' && p === '/api/admin/backup') {
      const snap = { app: 'CLS Reporting System v2', savedAt: nowIso(), users: db.users.map(pub), keys: db.keys };
      return send(req, res, 200, JSON.stringify(snap), 'application/json', { 'Content-Disposition': 'attachment; filename="CLS_Backup_' + nowIso().slice(0, 10) + '.json"', 'Cache-Control': 'no-store' });
    }
    if (m === 'POST' && p === '/api/admin/users/reset') {
      const target = findUser(body.code);
      if (!target || target.vacant) return err(req, res, 404, 'User not found.');
      const pw = body.password ? String(body.password) : tempPw();
      if (pw.length < 8) return err(req, res, 400, 'The password must have at least 8 characters.');
      setPw(target, pw, true); touch(); audit({ ev: 'pw-reset', by: user.code, code: target.code });
      return ok(req, res, { tempPassword: pw });
    }
    if (m === 'POST' && p === '/api/admin/passwords') {
      const list = [];
      for (const u of db.users) {
        if (u === user || u.active === false || u.vacant) continue;
        const pw = tempPw(); setPw(u, pw, true); list.push({ code: u.code, name: u.name, role: u.role, password: pw });
      }
      touch(); audit({ ev: 'pw-reset-all', by: user.code, n: list.length }); return ok(req, res, { list });
    }
  }
  return err(req, res, 404, 'Not found');
}

http.createServer((req, res) => { route(req, res).catch(e => { console.error(e); try { err(req, res, 500, 'Server error'); } catch (x) {} }); })
  .listen(PORT, () => console.log('CLS Reporting System v2 running on port ' + PORT + ' (data: ' + DATA_DIR + ')'));
