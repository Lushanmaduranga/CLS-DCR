# CLS Reporting System v2 - shared web application

One website for everyone. MPOs, Field Managers and the Business Manager sign in with their
employee code. Every entry is saved on the server, so the whole team works on **one shared dataset**
- nothing to download, and it works on phones.

## Who can see what (fixed list, enforced on the server)

| Role | Sees |
|---|---|
| MPO | Their own records only |
| FM-2244 P Dharma Raju | Own records + Chamara, M Muneeshwaran, Dinith, Keshara, Mayooran |
| FM-2575 Jeewaka Balasuriya | Own records + Prabodha, Madhawa, Rasith, Anurudda (and the vacant seat) |
| BM-2775 Lushan | Everything, plus Users & Access (reset passwords, backup) |

`MPO-Vecant` is a vacant position: it appears in the name lists but nobody can sign in with it.

The names, roles and reporting lines live in **roster.json**. To add, remove or move a person:
edit `roster.json` (keep `code`, `name`, `role`, `reportsTo`, `pid` - use a new unique `pid` for a new person),
then deploy again. Existing passwords and data are kept; new people get a password from
**Users & Access -> Create one-time passwords**.

## 1. Put it online - Azure App Service (HTTPS, needed for phones)

Use the portal steps below, or run `deploy-azure.sh` in Azure Cloud Shell
(Bash). The script is written from Microsoft's documentation and has not been run against a live subscription -
check names/region/plan with IT first.

Portal summary:
1. Create a **Web App**: Publish *Code*, Runtime *Node 20 LTS*, OS *Linux*, plan *Basic B1*.
2. **Settings > Environment variables > App settings**: add
   * `DATA_DIR` = `/home/data`  (survives restarts)
   * `CIC_ADMIN_PASSWORD` = your own strong password (used once, for BM-2775, on the first start only)
   * optional `FRAME_ANCESTORS` = `https://<yourtenant>.sharepoint.com` so a SharePoint page may embed the site
3. **Settings > Configuration > General settings**: *HTTPS Only* = On, *Startup command* = `node server.js`.
4. **Deployment Center > Manual Deployment (Push) > Publish files**: drag and drop `CLS_Web_App.zip`.
   (Files must be at the top level of the zip - they are.)
5. Keep the plan at **one instance** (data is stored in a file, so do not scale out).
6. Open `https://<app>.azurewebsites.net/healthz` -> `ok`. Sign in as **BM-2775**.
7. **Users & Access -> Create one-time passwords for everyone (CSV)**. Send each person their own password
   privately. Everyone chooses their own password at first sign-in.

Then share the **web link** (add it to a SharePoint Quick link or a Teams tab). Never share the HTML file.

## 2. Or run it on a company PC / server (office network only)

Install Node LTS, double-click `start.bat` (or run `node server.js`), open `http://<pc-name>:3000`.
The first start prints the BM password and saves it in `data/FIRST-RUN-ADMIN-PASSWORD.txt` (delete it after use).
Phones only allow location access on HTTPS, so prefer option 1 for field staff.

## Data, backups, security

* Everything is in the `data` folder: `db.json` (live data), `backups/` (one file a day, last 30 kept),
  `audit.log` (who changed what). Users & Access -> *Download full backup* works at any time.
* Passwords are stored scrambled (scrypt); nobody can read them. 5 wrong attempts lock sign-in for a minute (longer if repeated).
* A reset signs the person out everywhere.
* Known limits: SQL Sales, YTD targets, ROI targets, Distributor Stock and the Pharmacy/Doctor lists are company-wide
  data. Only the BM can change the sales/target/stock files, but a technically skilled signed-in user could read them.
  Prescription photos and IQVIA files attached in the app stay on the device that attached them.
  Visits entered in the old stand-alone HTML file are not moved automatically.
