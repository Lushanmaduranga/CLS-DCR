#!/usr/bin/env bash
# CLS Reporting System v2 - one-go Azure deployment (run in Azure Cloud Shell, Bash).
# Needs: an Azure subscription where you are Contributor/Owner, and CLS_Web_App.zip uploaded to Cloud Shell.
# NOTE: written from Microsoft's documentation and NOT run against a live subscription - read it through once
#       and check the names, region and plan with IT before you run it.
set -euo pipefail

APP_NAME="${APP_NAME:-cls-reporting-cic}"       # must be unique worldwide -> becomes https://<APP_NAME>.azurewebsites.net
RESOURCE_GROUP="${RESOURCE_GROUP:-rg-cls-reporting}"
LOCATION="${LOCATION:-southeastasia}"            # choose with IT (for example centralindia / southeastasia)
PLAN_NAME="${PLAN_NAME:-plan-cls-reporting}"
SKU="${SKU:-B1}"                                 # Basic. Keep ONE instance (data is stored in a file).
ZIP="${ZIP:-CLS_Web_App.zip}"
: "${CIC_ADMIN_PASSWORD:?Set a strong password first:  export CIC_ADMIN_PASSWORD='...your choice...'}"
# Optional: let your SharePoint page show the site in a frame (leave empty to block framing)
FRAME_ANCESTORS="${FRAME_ANCESTORS:-}"

az group create --name "$RESOURCE_GROUP" --location "$LOCATION"
az appservice plan create --name "$PLAN_NAME" --resource-group "$RESOURCE_GROUP" --is-linux --sku "$SKU"
az webapp create --name "$APP_NAME" --resource-group "$RESOURCE_GROUP" --plan "$PLAN_NAME" --runtime "NODE:20-lts"
az webapp update --name "$APP_NAME" --resource-group "$RESOURCE_GROUP" --https-only true
SETTINGS=(DATA_DIR=/home/data "CIC_ADMIN_PASSWORD=$CIC_ADMIN_PASSWORD")
if [ -n "$FRAME_ANCESTORS" ]; then SETTINGS+=("FRAME_ANCESTORS=$FRAME_ANCESTORS"); fi
az webapp config appsettings set --name "$APP_NAME" --resource-group "$RESOURCE_GROUP" --settings "${SETTINGS[@]}" >/dev/null
az webapp config set --name "$APP_NAME" --resource-group "$RESOURCE_GROUP" --startup-file "node server.js"
az webapp deploy --name "$APP_NAME" --resource-group "$RESOURCE_GROUP" --src-path "$ZIP" --type zip

echo
echo "Done. Open:  https://${APP_NAME}.azurewebsites.net"
echo "Health check: https://${APP_NAME}.azurewebsites.net/healthz  (should say: ok)"
echo "Sign in as BM-2775 with the CIC_ADMIN_PASSWORD you set, then open Users & Access."
